﻿// Your code here!
var svgContent;
function generateSensor() {
    console.log("Generating Sensor");
    var ellipseWidth = 10;
    var ellipseHeight = 10;
    var spacing = 20

    var draw = SVG('drawing').size(1500, 1000);
      /*  var ellipse1 = draw.ellipse(ellipseWidth, ellipseHeight).fill('#f06').x(50).y(60); */
 for(var outbox=0;outbox<5;outbox ++)
	 var rect = draw.rect(180, 180).fill('none').move(((outbox*240)+10),20).stroke({ width: 3 });	
	
   for (var Totallayers = 0; Totallayers <= 3; Totallayers++)
	{
		 /* Single coloumn Receiver along with Dots */							
		 for (var rxrow = 0; rxrow < 5; rxrow++)
		{
			for (var rxcolumn = 0; rxcolumn < 4; rxcolumn++) 
			{
	         /* var ellipse1 = draw.ellipse(ellipseWidth, ellipseHeight).fill('#f06').x(((Totallayers*240)+50+(rxcolumn*spacing))).y(60+(rxrow*spacing)); */
	      /* var ellipse2= draw.ellipse(ellipseWidth, ellipseHeight).fill('#f06').x(((Totallayers*240)+60+(rxcolumn*spacing))).y(50+(rxrow*spacing)); */
			   var ellipse2= draw.ellipse(ellipseWidth, ellipseHeight).fill('#000000').x(((4*240)+60+(rxcolumn*spacing))).y(50+(rxrow*spacing)); 
			   var line2 = draw.line((1025+rxcolumn*spacing), 25,(1025+rxcolumn*spacing), 180).stroke({ width: 3 }) 
	           var rect = draw.rect(180, 180).fill('none').move(((Totallayers*240)+10),20).stroke({ width: 3 });
		   }	
		}
		
		/* Single row Transmitter  along with Dots */
		 for (var txrow= 0; txrow< 4; txrow++)
		{
			for (var txcolumn= 0; txcolumn< 5; txcolumn++)
			{
	           var ellipse1 = draw.ellipse(ellipseWidth, ellipseHeight).fill('#000000').x((0*240)+50+(txcolumn*spacing)).y(60+(txrow*spacing));
			   
			   var line1 = draw.line((25), (65+txrow*spacing), 180, (65+txrow*spacing)).stroke({ width: 3 })
			   /* var ellipse2= draw.ellipse(ellipseWidth, ellipseHeight).fill('#f06').x(((Totallayers*240)+60+(column*spacing))).y(50+(row*spacing)); */
			  
		   }	
		}
		/* 2 loops for dielectric */
		 for (var Drow= 0; Drow< 4; Drow++)
		{
			for (var Dcolumn= 0; Dcolumn< 5; Dcolumn++)
			{
	           for (var di=1;di<4;di++)
			   {
				    var rect = draw.rect(120, 120).fill('#000000').move(((di*240)+35),40).stroke({ width: 3 });
					
			   }
			}
		}
			/*for white rows on dielectric*/
			   for (var Dummyr= 0; Dummyr< 4; Dummyr++)
		{
			for (var Dummyc= 0; Dummyc< 5; Dummyc++)
			{
			  	  for (var di1=1;di1<4;di1++){
			   var ellipse1 = draw.ellipse(ellipseWidth, ellipseHeight).fill('#fff').x((di1*240)+50+(Dummyc*spacing)).y(60+(Dummyr*spacing));       
				}
				
		    }
		}	
	
		 for (var Drow1= 0; Drow1< 5; Drow1++)
		{
			for (var Dcolumn1= 0; Dcolumn1< 4; Dcolumn1++)
			{
	           for (var di=1;di<4;di++)
			   {
				   /*var ellipse1 = draw.ellipse(ellipseWidth, ellipseHeight).fill('#f06').x((di*240)+50+(Dcolumn*spacing)).y(60+(Drow*spacing)); */
			       var ellipse2= draw.ellipse(ellipseWidth, ellipseHeight).fill('#fff').x(((di*240)+60+(Dcolumn1*spacing))).y(50+(Drow1*spacing));
			      
		        }	
					
		     }
		
		
        } 
	
	}
    svgContent = draw.svg();
 
	}

	function saveSVG() {
    console.log("Saving Svg");
    var uriContent = "data:application/octet-stream," + encodeURIComponent(svgContent);
    newWindow = window.open(uriContent, 'svgDocument');
}